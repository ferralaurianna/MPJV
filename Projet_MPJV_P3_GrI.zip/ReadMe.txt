Ce programme a été crée avec QTCreator et les bibliothèques associées, dont OpenGL. Afin de le compiler, il est donc nécessaire d'installer cet environnment dans sa version pour le développement open-source depuis le lien ci-dessous.

https://www.qt.io/download-qt-installer

On choisira le préréglage d'intallation: "Qt 6.3 pour le développement d'environnement de bureau"

Une fois le logiciel installé, il suffit d'ouvrir le projet depuis QT Creator en ouvrant le fichier .pro.

On laissera les paramètres de configuration du projet par défaut.

La compilation se fait par la flèche en bas à gauche.

Une fois sur la scène de la partie 3, il faut appuyez sur 1 pour lancer la première démo (objet tournouyant), et 2 pour lancer la seconde (collsion de pavés hardcodée).