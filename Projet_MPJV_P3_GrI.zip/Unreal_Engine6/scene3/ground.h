#ifndef GROUND_H
#define GROUND_H


class Ground
{
public:
    Ground();
};

#endif // GROUND_H
