#include "actorasset2.h"

actorasset2::actorasset2()
{

}
