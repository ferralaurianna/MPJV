#ifndef ACTORASSET2_H
#define ACTORASSET2_H


class actorasset2
{
public:
    actorasset2();
};

#endif // ACTORASSET2_H
