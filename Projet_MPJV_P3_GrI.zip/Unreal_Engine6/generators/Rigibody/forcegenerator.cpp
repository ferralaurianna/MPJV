#include "forcegenerator.h"

ForceGenerator::ForceGenerator()
{

}

ForceGenerator::~ForceGenerator(){

}
