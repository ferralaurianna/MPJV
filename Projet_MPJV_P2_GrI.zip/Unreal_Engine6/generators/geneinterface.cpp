#include "geneinterface.h"

GeneInterface::GeneInterface()
{

}

GeneInterface::~GeneInterface()
{

}
