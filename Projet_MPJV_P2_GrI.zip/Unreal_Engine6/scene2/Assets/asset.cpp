#include "asset.h"

Asset::Asset()
{

}
